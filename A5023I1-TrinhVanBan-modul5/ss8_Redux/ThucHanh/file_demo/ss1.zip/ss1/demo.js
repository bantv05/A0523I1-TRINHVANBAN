// let obj = {
//     a: 1,
//     b: () => {
//         console.log(this, this.a);
//     },
//     c: function() {
//         console.log(this, this.a);
//     }
// }
// obj.b();
// obj.c();


// function Dog(id, name) {
//     this.id = id;
//     this.name = name;
// }
// let dog = new Dog(1, "abc")

