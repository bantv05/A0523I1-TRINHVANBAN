function NotFound(){
    return(
        <div>
            <h1>Trang web chưa cập nhật</h1>
        </div>
    )
}

export default NotFound;