import { Link } from "react-router-dom";
import * as Order from "../service/OrderService";
import "../css/List.css";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import Moment from "moment";
import NotFound from "../pages/NotFound";

function ListOrder() {
    const [order, setOrder] = useState([]);
    const [product, setProduct] = useState([]);
    const [records, setRecords] = useState([]);
    const [valueI, setValue] = useState('');

    const getAllOrder = async () => {
        const temp = await Order.getAllOrder();
        setOrder(temp);
        setRecords(temp);
    }

    const getAllProduct = async () => {
        const temp = await Order.getAllProduct();
        setProduct(temp);
    }

    useEffect(() => {
        getAllOrder();
        getAllProduct();
    }, []);

    const handleDelete = async (id, name) => {
        const confirm = window.confirm("Bạn có muốn xóa " + name + " không?");
        if (confirm) {
            await Order.deleteOrder(id);
            setOrder(prevState => prevState.filter(order => order.id !== id));
            toast.success("👌 Xóa thành công");
        }
    }

    const calculateTotal = (order) => {
        return order.soLuong * order.product.gia;
    }

    const handleSearch = async (valueI) =>{
        if (valueI) {
            const temp = await Order.searchProduct(valueI);
            setRecords(temp);
        } else {
            setRecords(order);
        }
    }

    const search = (e) =>{
        const { name, value } = e.target;
        setValue(value);
    }

    useEffect(() => {
        handleSearch(valueI);
    }, [valueI]);

    const handleReset = () => {
        setValue('');
        setRecords(order);
    }

    return (
        <div className="container">
            <div className="content">
                <form style={{ display: "flex" }}>
                    <div>
                        <select
                            style={{ width: 300 }}
                            name="type"
                            onChange={search}
                        >
                            <option value="">--Select search--</option>
                            {product.map((item, key) => (
                                <option key={key} value={item.name}>{item.name}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <button type="button" onClick={() => handleSearch(valueI)}>Search</button>
                        <button type="button" onClick={handleReset}>Reset</button>
                    </div>
                </form>
                <h1 className="title">List Product</h1>
                <div className="btnAddn">
                    <Link to="/create" className="btnAdd">Add+</Link>
                </div>
                <table>
                    <thead>
                    <tr className="row">
                        <th>STT</th>
                        <th>Mã đơn hàng</th>
                        <th>Tên sản phẩm</th>
                        <th>Ngày mua</th>
                        <th>Giá</th>
                        <th>Số lượng</th>
                        <th>Loại sản phẩm</th>
                        <th>Tổng tiền</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    {records.length > 0 ? (
                        records.map((order, key) => (
                            <tr key={key}>
                                <td>{key + 1}</td>
                                <td>{order.id}</td>
                                <td>{order.product.name}</td>
                                <td>{Moment(order.ngayMua).format("DD-MM-yyyy")}</td>
                                <td>{order.product.gia}</td>
                                <td>{order.soLuong}</td>
                                <td>{order.product.lsp}</td>
                                <td>{calculateTotal(order)}</td>
                                <td className="button">
                                    <button onClick={() => handleDelete(order.id, order.product.name)} className="btn3">Delete</button>
                                </td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="9">
                                <NotFound />
                            </td>
                        </tr>
                    )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}

export default ListOrder;
